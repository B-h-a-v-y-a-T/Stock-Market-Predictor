import os
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Integer, JSON


DATABASE_URL = os.getenv("DATABASE_URL", "")

# Support both sync and async URLs; enforce async with asyncpg if present
def _to_async_url(url: str) -> str:
    if not url:
        return ""
    if url.startswith("postgresql+asyncpg://"):
        return url
    if url.startswith("postgres://"):
        url = url.replace("postgres://", "postgresql://", 1)
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+asyncpg://", 1)
    return url


ASYNC_DB_URL = _to_async_url(DATABASE_URL)


class Base(DeclarativeBase):
    pass


class AnalysisRecord(Base):
    __tablename__ = "analysis_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    input_type: Mapped[str] = mapped_column(String(32), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    result: Mapped[dict] = mapped_column(JSON, nullable=True)


engine = create_async_engine(ASYNC_DB_URL, echo=False) if ASYNC_DB_URL else None
SessionLocal = async_sessionmaker(engine, expire_on_commit=False) if engine else None


async def init_db() -> None:
    if not engine:
        return
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    if not SessionLocal:
        raise RuntimeError("DATABASE_URL not configured")
    async with SessionLocal() as session:
        yield session








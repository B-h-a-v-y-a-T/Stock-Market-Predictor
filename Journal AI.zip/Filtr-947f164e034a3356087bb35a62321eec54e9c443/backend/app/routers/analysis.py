from typing import Any, Dict

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ..services.llm_agent import run_agent_workflow


router = APIRouter()


class QueryPayload(BaseModel):
    type: str = Field(..., description="Type of analysis: url|text|image|video")
    payload: Dict[str, Any] = Field(..., description="Payload to analyze")


@router.post("/query")
async def query(payload: QueryPayload) -> Dict[str, Any]:
    """Run the verification workflow and always return a structured response."""
    try:
        result = await run_agent_workflow(payload.type, payload.payload)
        return {"status": "completed", **result}
    except Exception as exc:
        # Ensure frontend never receives a blank; provide useful error info
        return {
            "status": "error",
            "summary": f"Analysis failed: {exc}",
            "verdict": "Uncertain",
            "evidence": [],
            "sources": [],
        }



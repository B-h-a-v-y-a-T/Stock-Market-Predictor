import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type AnalysisType = "url" | "text" | "image" | "video";

type AnalyzePayload = {
  type: AnalysisType;
  payload: Record<string, any>;
};

type AnalyzeResponse = {
  status?: string;
  summary?: string;
  verdict?: string;
  evidence?: Array<{
    source: string;
    confidence: number;
    url?: string;
    rationale?: string;
  }>;
  sources?: string[];
  sentiment?: Record<string, any>;
};

export function useAletheia() {
  const apiBase = useMemo(() => {
    // Prefer current host to avoid localhost/127.0.0.1 mismatch
    if (typeof window !== "undefined") {
      const host = window.location.hostname || "127.0.0.1";
      const proto = window.location.protocol === "https:" ? "https" : "http";
      return `${proto}://${host}:8000`;
    }
    return "http://127.0.0.1:8000";
  }, []);

  const wsUrl = useMemo(() => {
    if (typeof window !== "undefined") {
      const host = window.location.hostname || "127.0.0.1";
      const proto = window.location.protocol === "https:" ? "wss" : "ws";
      return `${proto}://${host}:8000/ws/threats`;
    }
    return "ws://127.0.0.1:8000/ws/threats";
  }, []);

  const [lastMessage, setLastMessage] = useState<any>(null);
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<number | null>(null);
  const reconnectAttempts = useRef(0);
  const shouldReconnectRef = useRef(true);

  const clearReconnectTimer = useCallback(() => {
    if (reconnectTimer.current !== null) {
      if (typeof window !== "undefined") {
        window.clearTimeout(reconnectTimer.current);
      }
      reconnectTimer.current = null;
    }
  }, []);

  const connect = useCallback(() => {
    if (wsRef.current && (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)) {
      return;
    }
    
  const ws = new WebSocket(wsUrl);
  // Optional: small debug to help track state in DevTools
  // eslint-disable-next-line no-console
  console.debug("[WS] connecting to", wsUrl);
    
    ws.onopen = () => {
      setIsConnected(true);
      reconnectAttempts.current = 0;
      clearReconnectTimer();
      // eslint-disable-next-line no-console
      console.debug("[WS] connected");
    };
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setLastMessage(data);
      } catch {
        setLastMessage(event.data);
      }
      // eslint-disable-next-line no-console
      console.debug("[WS] message", event.data);
    };
    
    ws.onclose = () => {
      setIsConnected(false);
      if (wsRef.current === ws) {
        wsRef.current = null;
      }
      if (shouldReconnectRef.current && typeof window !== "undefined") {
        clearReconnectTimer();
        const delay = Math.min(1000 * 2 ** reconnectAttempts.current, 15000);
        reconnectAttempts.current = Math.min(reconnectAttempts.current + 1, 10);
        reconnectTimer.current = window.setTimeout(() => {
          reconnectTimer.current = null;
          connect();
        }, delay);
      }
      // eslint-disable-next-line no-console
      console.debug("[WS] closed - will reconnect");
    };
    
    ws.onerror = () => {
      setIsConnected(false);
      try {
        ws.close();
      } catch {
        /* noop */
      }
      // eslint-disable-next-line no-console
      console.debug("[WS] error");
    };
    
    wsRef.current = ws;
  }, [wsUrl, clearReconnectTimer]);

  const disconnect = useCallback(() => {
    clearReconnectTimer();
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, [clearReconnectTimer]);

  useEffect(() => {
    reconnectAttempts.current = 0;
    shouldReconnectRef.current = true;
    connect();
    return () => {
      shouldReconnectRef.current = false;
      clearReconnectTimer();
      disconnect();
    };
  }, [connect, disconnect, clearReconnectTimer]);

  const analyze = useCallback(
    async ({ type, payload }: AnalyzePayload): Promise<AnalyzeResponse> => {
      const res = await fetch(`${apiBase}/api/v1/query`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, payload }),
      });
      if (!res.ok) {
        throw new Error(`Request failed: ${res.status}`);
      }
      return (await res.json()) as AnalyzeResponse;
    },
    [apiBase]
  );

  return { analyze, connect, disconnect, isConnected, lastMessage };
}

export default useAletheia;



import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import useAletheia from "@/hooks/useAletheia";

type Result = {
  summary?: string;
  verdict?: string;
  confidence?: number; // 0-100 percentage
  evidence?: Array<{ source: string; confidence: number; url?: string; rationale?: string }>;
  sources?: string[];
  sentiment?: Record<string, unknown>;
};

const VerificationWorkbench = () => {
  const { analyze, connect, disconnect, lastMessage, isConnected } = useAletheia();
  const [url, setUrl] = useState("");
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [showVeracity, setShowVeracity] = useState(false);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const type = url ? "url" : "text";
      const payload = url ? { url } : { text };
      const res = await analyze({ type, payload });
      setResult(res as Result);
    } catch (e) {
      setResult({ summary: "Request failed.", verdict: "Unknown", evidence: [] });
    } finally {
      setLoading(false);
    }
  };

  const threatBanner = useMemo(() => {
    if (!lastMessage || typeof lastMessage !== "object") return null;
    if (lastMessage.type !== "threat") return null;
    return (
      <div className="rounded-md border border-yellow-400 bg-yellow-50 text-yellow-900 px-4 py-2">
        <div className="text-sm font-medium">Live Threat Alert</div>
        <div className="text-xs opacity-80">{lastMessage.message} (Level {lastMessage.level})</div>
      </div>
    );
  }, [lastMessage]);

  return (
    <div className="space-y-4">
      {threatBanner}

      <Card>
        <CardHeader>
          <CardTitle>Verification Workbench</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            placeholder="Paste a URL to verify (optional)"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
          <Textarea
            placeholder="Or paste text content to verify"
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={4}
          />
          <div className="flex items-center gap-2">
            <Button onClick={handleSubmit} disabled={loading} className="bg-gradient-primary">
              {loading ? "Analyzing..." : "Analyze"}
            </Button>
            <Button variant="outline" onClick={() => setShowVeracity(true)} disabled={!result}>
              View Veracity Chain
            </Button>
            <span className="text-xs text-muted-foreground ml-auto">
              WS: {isConnected ? "connected" : "disconnected"}
            </span>
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Verification Result</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="text-sm">
              <span className="font-medium">Verdict:</span> {result.verdict}
              {result.confidence !== undefined && (
                <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                  {result.confidence.toFixed(1)}% confidence
                </span>
              )}
            </div>
            <div className="text-sm whitespace-pre-wrap">
              <span className="font-medium">Summary:</span> {result.summary}
            </div>
            <div className="text-sm">
              <div className="font-medium mb-1">Evidence</div>
              <ul className="list-disc pl-5">
                {(result.evidence || []).map((e, i) => (
                  <li key={i} className="text-sm">
                    {e.source}
                    {e.url ? (
                      <>
                        {" "}
                        <a className="underline" href={e.url} target="_blank" rel="noreferrer">
                          source
                        </a>
                      </>
                    ) : null}
                    {" "}— confidence {(e.confidence * 100).toFixed(0)}%
                    {e.rationale ? <div className="text-xs text-muted-foreground">{e.rationale}</div> : null}
                  </li>
                ))}
              </ul>
            </div>
            {result.sources && result.sources.length > 0 ? (
              <div className="text-sm">
                <div className="font-medium mb-1">Sources</div>
                <ul className="list-disc pl-5">
                  {result.sources.map((src, idx) => (
                    <li key={idx}>
                      <a className="underline" href={src} target="_blank" rel="noreferrer">
                        {src}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}

      {showVeracity && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card border rounded-lg w-full max-w-3xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-semibold">Veracity Chain (D3 stub)</div>
              <Button size="sm" variant="outline" onClick={() => setShowVeracity(false)}>Close</Button>
            </div>
            <div className="h-64 rounded-md border flex items-center justify-center text-sm text-muted-foreground">
              D3 graph placeholder
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VerificationWorkbench;


